from pytubefix import YouTube
from pytubefix.cli import on_progress

urlyt = input("url youtube:")

# Criar objeto youtube
yt = YouTube(urlyt, 
             on_progress_callback=on_progress)


"""  ###- CASO EU QUEIRA BAIXAR O VIDEO -###
video = yt.streams.filter(resolution='1080p').first()
if video:
    print('Downloading Video...')
    video.download(filename=f'{yt.title}video.mp4')
else:
    pass
"""

# Baixa o mp3
audio = yt.streams.filter(only_audio=True).first()
if audio:
    print('Downloading Audio...')
    audio.download(filename=f'{yt.title}audio.mp4')
else:
    pass